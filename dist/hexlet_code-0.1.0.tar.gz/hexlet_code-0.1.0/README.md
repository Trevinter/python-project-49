### Hexlet tests and linter status:
[![Actions Status](https://github.com/Trevinter/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Trevinter/python-project-49/actions)